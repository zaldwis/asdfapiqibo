<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateItemOrders extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('item_orders', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('id_order');
            $table->bigInteger('id_menu');
            $table->integer('quantity');
            $table->bigInteger('unit_price');
            $table->bigInteger('total_price');
            $table->string('order_message');
            $table->boolean('is_cancel');
            $table->string('cancel_message')->nullable();

            $table->timestamps();
            $table->index('id_order', 'FK_item_orders_orders');
            $table->index('id_menu', 'FK_item_orders_menus');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('item_orders');
    }
}
