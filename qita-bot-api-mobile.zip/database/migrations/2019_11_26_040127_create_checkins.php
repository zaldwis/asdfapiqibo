<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCheckins extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('checkins', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('id_restaurant');
            $table->bigInteger('id_table');
            $table->bigInteger('id_user');
            $table->datetime('checkin_datetime');
            $table->datetime('checkout_datetime')->nullable();
            $table->boolean('is_checkin')->nullable();

            $table->timestamps();
            $table->index('id_table', 'FK_checkins_tables');
            $table->index('id_user', 'FK_checkins_users');
            $table->index('id_restaurant', 'FK_checkins_restaurants');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('checkins');
    }
}
