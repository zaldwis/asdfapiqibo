<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCallings extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('callings', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('id_restaurant');
            $table->bigInteger('id_table');
            $table->bigInteger('id_user');
            $table->boolean('is_active')->nullable();

            $table->timestamps();
            $table->index('id_table', 'FK_callings_tables');
            $table->index('id_user', 'FK_callings_users');
            $table->index('id_restaurant', 'FK_callings_restaurants');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('callings');
    }
}
