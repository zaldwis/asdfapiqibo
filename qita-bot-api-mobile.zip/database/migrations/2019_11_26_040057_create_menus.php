<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMenus extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('menus', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('id_restaurant');
            $table->bigInteger('id_menu_category');
            $table->string('name');
            $table->string('description');
            $table->string('image');
            $table->bigInteger('price');
            $table->boolean('is_available')->nullable();

            $table->timestamps();
            $table->index('id_restaurant', 'FK_menus_restaurants');
            $table->index('id_menu_category', 'FK_menus_menu_categories');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('menus');
    }
}
