<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class Restaurants extends Model
{
	protected $table = 'restaurants';
}

