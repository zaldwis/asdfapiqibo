<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class Checkins extends Model
{
	protected $table = 'checkins';
}

