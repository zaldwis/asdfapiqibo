<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class FriendRequests extends Model
{
	protected $table = 'friend_requests';
}

