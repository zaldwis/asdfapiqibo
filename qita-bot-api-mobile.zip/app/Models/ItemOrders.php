<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class ItemOrders extends Model
{
	protected $table = 'item_orders';
}

