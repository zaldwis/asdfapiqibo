<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class Callings extends Model
{
	protected $table = 'callings';
}

