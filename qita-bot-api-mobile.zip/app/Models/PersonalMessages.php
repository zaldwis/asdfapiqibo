<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class PersonalMessages extends Model
{
	protected $table = 'message_personals';
}

