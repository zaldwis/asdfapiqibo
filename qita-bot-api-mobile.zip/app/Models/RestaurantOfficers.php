<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class RestaurantOfficers extends Model
{
	protected $table = 'restaurant_officers';
}

