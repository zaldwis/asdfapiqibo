<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class BotMessages extends Model
{
	protected $table = 'message_bot';
}

