<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class MenuCategories extends Model
{
	protected $table = 'menu_categories';
}

