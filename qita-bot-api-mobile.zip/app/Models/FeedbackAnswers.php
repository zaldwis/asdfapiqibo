<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class FeedbackAnswers extends Model
{
	protected $table = 'feedback_answers';
}

