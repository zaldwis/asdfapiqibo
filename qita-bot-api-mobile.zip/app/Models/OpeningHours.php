<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class OpeningHours extends Model
{
	protected $table = 'opening_hours';
}

